#!/usr/bin/env python3
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
import os
import openai
class DefaultConfig:
    """ Bot Configuration """
    PORT = 3978
    APP_ID = os.environ.get("MicrosoftAppId", "cec37783-14c1-422a-a381-1be541be12a2")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "voq8Q~l8O2S2JsYS8zmuKuenlQeyEEWchX3KKakC")

    ai_search_url = "https://mtccogssearch.search.windows.net"
    ai_search_key = "f2f8PE1VeMR5fR0C1uCJXzgEY7tb81aO352GMh7daDAzSeBaFGO2"
    ai_index_name = "contoso-retail-index"
    ai_semantic_config = "contoso-retail-config"

    az_db_server = "cdcsampledbserver.database.windows.net"
    az_db_database = "cdcsampledb"
    az_db_username = "onepageradmin"
    az_db_password = "MtcPass$197235"

    az_openai_key = "f9f6178d2045490eb5dc707d1889c1f6"
    az_openai_baseurl = "https://aoai-975.openai.azure.com/"
    az_openai_type = "azure"
    az_openai_version_latest = "2023-08-01-preview"
    az_openai_version = "2023-07-01-preview"
    # deployment_name = "turbo0613"  # T
    deployment_name = "gpt-4"  # T
